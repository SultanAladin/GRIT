import { useFrame, useThree } from '@react-three/fiber';
import { Sky, OrbitControls, PerspectiveCamera, Environment, CubeCamera } from '@react-three/drei';
import { useEffect, useMemo, useRef, useState } from 'react';
import * as THREE from 'three';
import { AtmosphereSettings, presets } from '../store';

// Handles WASD Movement while using OrbitControls
function PlayerMovement({ orbitRef }: { orbitRef: any }) {
  const { camera } = useThree();
  const keys = useRef({ w: false, a: false, s: false, d: false });

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'w' || e.key === 'W') keys.current.w = true;
      if (e.key === 'a' || e.key === 'A') keys.current.a = true;
      if (e.key === 's' || e.key === 'S') keys.current.s = true;
      if (e.key === 'd' || e.key === 'D') keys.current.d = true;
    };
    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key === 'w' || e.key === 'W') keys.current.w = false;
      if (e.key === 'a' || e.key === 'A') keys.current.a = false;
      if (e.key === 's' || e.key === 'S') keys.current.s = false;
      if (e.key === 'd' || e.key === 'D') keys.current.d = false;
    };
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  useFrame((_, delta) => {
    if (!orbitRef.current) return;
    const speed = 100 * delta; // units per second
    const frontVector = new THREE.Vector3(0, 0, (keys.current.s ? 1 : 0) - (keys.current.w ? 1 : 0));
    const sideVector = new THREE.Vector3((keys.current.d ? 1 : 0) - (keys.current.a ? 1 : 0), 0, 0);
    
    // Move relative to camera look direction
    frontVector.applyQuaternion(camera.quaternion);
    sideVector.applyQuaternion(camera.quaternion);
    
    // Normalize to prevent faster diagonal movement
    const moveVector = new THREE.Vector3().add(frontVector).add(sideVector);
    if (moveVector.lengthSq() > 0) moveVector.normalize().multiplyScalar(speed);
    
    if (keys.current.w || keys.current.s || keys.current.a || keys.current.d) {
      camera.position.add(moveVector);
      orbitRef.current.target.add(moveVector);
    }
  });

  return null;
}

// True Volumetric 3D Noise Raymarching for Clouds
function RaymarchedClouds({ radius, settings, center }: { radius: number, settings: AtmosphereSettings, center: THREE.Vector3 }) {
  const materialRef = useRef<THREE.ShaderMaterial>(null);

  useFrame(({ clock, camera }) => {
    if (materialRef.current) {
      materialRef.current.uniforms.uTime.value = clock.getElapsedTime();
      materialRef.current.uniforms.uCloudOpacity.value = settings.cloudOpacity;
      materialRef.current.uniforms.uCloudSpeed.value = settings.cloudSpeed;
      materialRef.current.uniforms.uCloudColor.value.set(settings.cloudColor);
      materialRef.current.uniforms.uThickness.value = settings.cloudVolume / 100;
      materialRef.current.uniforms.uSeed.value = settings.cloudSeed;
      materialRef.current.uniforms.uCameraPos.value.copy(camera.position);
    }
  });

  return (
    <mesh>
      <sphereGeometry args={[radius * 0.98, 32, 32]} />
      <shaderMaterial
        ref={materialRef}
        transparent
        side={THREE.BackSide} // allows looking into the volume from outside
        depthWrite={false}
        uniforms={{
          uTime: { value: 0 },
          uCloudColor: { value: new THREE.Color() },
          uCloudOpacity: { value: 1 },
          uCloudSpeed: { value: 0 },
          uThickness: { value: 0.2 },
          uSeed: { value: 1 },
          uCameraPos: { value: new THREE.Vector3() },
          uRadius: { value: radius },
          uCenter: { value: center }
        }}
        vertexShader={`
          varying vec3 vWorldPos;
          void main() {
            vec4 worldPosition = modelMatrix * vec4(position, 1.0);
            vWorldPos = worldPosition.xyz;
            gl_Position = projectionMatrix * viewMatrix * worldPosition;
          }
        `}
        fragmentShader={`
          varying vec3 vWorldPos;
          uniform float uTime;
          uniform vec3 uCloudColor;
          uniform float uCloudOpacity;
          uniform float uCloudSpeed;
          uniform float uThickness;
          uniform float uSeed;
          uniform vec3 uCameraPos;
          uniform float uRadius;
          uniform vec3 uCenter;

          float hash(vec3 p) {
            p = fract(p * 0.3183099 + 0.1);
            p *= 17.0;
            return fract(p.x * p.y * p.z * (p.x + p.y + p.z));
          }

          float noise(vec3 x) {
            vec3 i = floor(x);
            vec3 f = fract(x);
            f = f * f * (3.0 - 2.0 * f);
            return mix(mix(mix(hash(i + vec3(0,0,0)), hash(i + vec3(1,0,0)), f.x),
                           mix(hash(i + vec3(0,1,0)), hash(i + vec3(1,1,0)), f.x), f.y),
                       mix(mix(hash(i + vec3(0,0,1)), hash(i + vec3(1,0,1)), f.x),
                           mix(hash(i + vec3(0,1,1)), hash(i + vec3(1,1,1)), f.x), f.y), f.z);
          }

          float fbm(vec3 p) {
            float f = 0.0;
            f += 0.5000 * noise(p); p = p * 2.02;
            f += 0.2500 * noise(p); p = p * 2.03;
            f += 0.1250 * noise(p); p = p * 2.01;
            f += 0.0625 * noise(p);
            return f;
          }

          void main() {
            vec3 rayDir = normalize(vWorldPos - uCameraPos);
            
            // March backwards from the back side of the sphere towards the camera
            vec3 pos = vWorldPos;
            float stepSize = uRadius * 0.05; 
            vec3 step = -rayDir * stepSize;
            
            float alphaAcc = 0.0;
            vec3 colorAcc = vec3(0.0);
            
            for(int i = 0; i < 20; i++) {
               vec3 localPos = pos - uCenter;
               
               // bounds check
               if (length(localPos) > uRadius) {
                   pos += step;
                   continue;
               }

               vec3 samplePos = localPos * 0.05 + vec3(uSeed * 100.0);
               samplePos.x += uTime * uCloudSpeed * 0.3;
               samplePos.z += uTime * uCloudSpeed * 0.1;
               
               float n = fbm(samplePos);
               
               float density = smoothstep(0.7 - uThickness, 0.7 + uThickness, n);
               
               // Constrain clouds to upper hemisphere
               float yFade = smoothstep(uRadius * 0.2, uRadius * 0.5, localPos.y); 
               float topFade = smoothstep(uRadius * 0.9, uRadius * 0.6, localPos.y); 
               
               density *= (yFade * topFade * uCloudOpacity);
               
               if(density > 0.01) {
                  colorAcc += uCloudColor * density * (1.0 - alphaAcc);
                  alphaAcc += density * (1.0 - alphaAcc);
               }
               
               if(alphaAcc >= 0.99) break;
               
               pos += step;
            }
            
            if(alphaAcc < 0.01) discard;
            
            gl_FragColor = vec4(colorAcc, alphaAcc);
          }
        `}
      />
    </mesh>
  );
}

// Represents a localized, spherical dome.
function PortalDome({ position, settings, radius = 60, isMain = false }: { position: [number, number, number], settings: AtmosphereSettings, radius?: number, isMain?: boolean }) {
  const skyRef = useRef<any>(null);

  useEffect(() => {
    // We override the default Drei Sky Box with a Sphere Geometry
    if (skyRef.current) {
      skyRef.current.geometry = new THREE.SphereGeometry(radius, 32, 32);
      if (skyRef.current.material) {
         // CRITICAL: We use BackSide so that from outside, we look *through* the front wall 
         // and see the sky painted on the inside back wall! This creates the portal effect.
         skyRef.current.material.side = THREE.BackSide;
         // Enable depthWrite so multiple spheres sort over each other correctly when viewed from outside
         skyRef.current.material.depthWrite = true;
      }
      skyRef.current.frustumCulled = false;
    }
  }, [radius]);

  const sunPosition = useMemo(() => {
    const phi = THREE.MathUtils.degToRad(90 - settings.elevation);
    const theta = THREE.MathUtils.degToRad(settings.azimuth);
    return new THREE.Vector3().setFromSphericalCoords(1, phi, theta);
  }, [settings.elevation, settings.azimuth]);

  return (
    <group position={position}>
      {/* The Procedural Sky mapped strictly to this Sphere */}
      <Sky
        ref={skyRef}
        sunPosition={sunPosition}
        turbidity={settings.turbidity}
        rayleigh={settings.rayleigh}
        mieCoefficient={settings.mieCoefficient}
        mieDirectionalG={settings.mieDirectionalG}
        distance={1} // Important! Keep scale 1 since we use SphereGeometry(radius)
      />

      {/* Wireframe Hull so we can visually see the dome boundaries from outside */}
      <mesh>
        <sphereGeometry args={[radius * 1.01, 32, 32]} />
        <meshBasicMaterial wireframe color={isMain ? "#ffffff" : "#4444ff"} transparent opacity={0.15} />
      </mesh>

      {/* Localized Point Light so lights do not bleed across worlds */}
      <pointLight
        position={sunPosition.clone().multiplyScalar(radius * 0.8)}
        intensity={settings.elevation > 0 ? 50000 : 0}
        color={settings.elevation < 10 ? "#ffb380" : "#ffffff"}
        distance={radius}
        decay={2}
      />

      <CubeCamera key={JSON.stringify(settings)} frames={1} resolution={256} near={0.1} far={1000} position={[0, 5, 0]}>
        {(texture) => (
          <group>
            {/* Reflective Shapes inside the dome */}
            <mesh position={[-20, 5, 10]}>
              <sphereGeometry args={[10, 64, 64]} />
              <meshStandardMaterial color="#ffffff" metalness={1} roughness={0.05} envMap={texture} />
            </mesh>
            
            <mesh position={[20, 8, -10]} rotation={[Math.PI/4, Math.PI/4, 0]}>
              <boxGeometry args={[12, 12, 12]} />
              <meshStandardMaterial color="#ffffff" metalness={0.9} roughness={0.1} envMap={texture} />
            </mesh>

            <mesh position={[0, 4, -25]} rotation={[Math.PI/2, 0, 0]}>
              <torusGeometry args={[8, 2, 32, 64]} />
              <meshStandardMaterial color="#ffffff" metalness={1} roughness={0.0} envMap={texture} />
            </mesh>

            {/* Additional highly reflective shapes added to test different angles */}
            <mesh position={[-15, 15, -20]} rotation={[Math.PI/6, Math.PI/3, 0]}>
              <octahedronGeometry args={[6, 0]} />
              <meshStandardMaterial color="#ffd700" metalness={1} roughness={0.1} envMap={texture} />
            </mesh>

            <mesh position={[10, 2, 20]} rotation={[0, Math.PI/4, 0]}>
              <cylinderGeometry args={[4, 4, 15, 32]} />
              <meshStandardMaterial color="#c0c0c0" metalness={0.8} roughness={0.0} envMap={texture} />
            </mesh>
            
            <mesh position={[0, 15, 0]}>
              <sphereGeometry args={[4, 64, 64]} />
              <meshStandardMaterial color="#ff5555" metalness={1} roughness={0.0} envMap={texture} />
            </mesh>

            {/* Localized floor disc */}
            <mesh position={[0, -5, 0]}>
              <cylinderGeometry args={[radius, radius, 1, 64, 4]} />
              <meshStandardMaterial color="#1a1c21" roughness={0.8} envMap={texture} />
            </mesh>
          </group>
        )}
      </CubeCamera>

      {/* 3D Noise Volumetric Clouds bounded within this specific dome */}
      {settings.cloudOpacity > 0 && (
        <RaymarchedClouds radius={radius} settings={settings} center={new THREE.Vector3(...position)} />
      )}
    </group>
  );
}

export function SkyScene({ domes }: { domes: any[] }) {
  const orbitRef = useRef<any>(null);

  return (
    <>
      <color attach="background" args={['#000000']} />
      <ambientLight intensity={0.2} />

      {domes.map((dome, i) => (
        <PortalDome key={dome.id} position={dome.position} settings={dome.settings} radius={100} isMain={i === 0} />
      ))}

      {/* A connecting tunnel/bridge to view both sides at once! Tessellated for better per-vertex lighting calculation if needed */}
      <mesh position={[0, -4.5, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <planeGeometry args={[300, 20, 64, 4]} />
        <meshStandardMaterial color="#333333" roughness={0.8} />
      </mesh>

      {/* Camera setup */}
      <PerspectiveCamera makeDefault position={[-50, 5, 20]} />
      {/* Target is placed slightly in front of the camera to act as a local pivot, allowing first-person "look around" style dragging! */}
      <OrbitControls ref={orbitRef} makeDefault target={[-51, 5, 20]} maxDistance={1500} enableDamping dampingFactor={0.05} />
      <PlayerMovement orbitRef={orbitRef} />
    </>
  );
}
