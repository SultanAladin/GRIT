import React, { useState } from 'react';
import { Settings, Cloud, Sun, ArrowLeft, Moon, CloudRain, Droplets, Wind } from 'lucide-react';
import { AtmosphereSettings, presets } from '../store';
import { cn } from '../lib/utils';

interface UIOverlayProps {
  domes: { id: number, name: string, position: [number, number, number], settings: AtmosphereSettings }[];
  setDomes: React.Dispatch<React.SetStateAction<any[]>>;
  activeDomeId: number;
  setActiveDomeId: (id: number) => void;
}

export function UIOverlay({ domes, setDomes, activeDomeId, setActiveDomeId }: UIOverlayProps) {
  const [activeTab, setActiveTab] = useState<'sky' | 'clouds' | 'fog'>('sky');

  const activeDome = domes.find(d => d.id === activeDomeId) || domes[0];
  const settings = activeDome.settings;

  const handlePreset = (presetName: keyof typeof presets) => {
    setDomes(prev => prev.map(d => d.id === activeDomeId ? { ...d, settings: presets[presetName] } : d));
  };

  const handleSlider = (key: keyof AtmosphereSettings, value: number | string) => {
    setDomes(prev => prev.map(d => d.id === activeDomeId ? { ...d, settings: { ...d.settings, [key]: value as any } } : d));
  };

  return (
    <div className="absolute inset-0 pointer-events-none p-4 md:p-8 flex flex-col justify-between" style={{ fontFamily: 'Inter, sans-serif' }}>
      
      {/* Top Banner & Nav */}
      <div className="flex justify-between items-start pointer-events-auto">
        <div className="flex flex-col">
          <div className="flex items-center space-x-4 mb-4 text-white">
            <ArrowLeft className="w-5 h-5 cursor-pointer hover:text-gray-300" />
            <h1 className="text-3xl font-light tracking-wide leading-tight">
              Spherical<br /><span className="font-semibold">Portals</span>
            </h1>
          </div>
          <p className="text-xs text-white/50 w-72 leading-relaxed bg-black/40 backdrop-blur-md p-3 rounded-xl border border-white/10">
            <strong>Controls:</strong> Left click & drag to look around. Use <strong>W, A, S, D</strong> to move anywhere. Domes are fully isolated habitats!
          </p>
        </div>

        {/* Top Middle Navigation (simulating Exterior/Interior tabs) */}
        <div className="hidden md:flex space-x-8 text-sm bg-black/40 backdrop-blur-md px-8 py-3 rounded-full border border-white/5">
          <button onClick={() => handlePreset('clear')} className="text-white hover:text-gray-300 transition-colors">Clear Sky</button>
          <button onClick={() => handlePreset('sunset')} className="text-white hover:text-gray-300 transition-colors">Sunset</button>
          <button onClick={() => handlePreset('overcast')} className="text-white hover:text-gray-300 transition-colors">Overcast</button>
          <button onClick={() => handlePreset('night')} className="text-white hover:text-gray-300 transition-colors">Night</button>
        </div>

        <div>
          <button className="bg-black/40 backdrop-blur-md text-white px-6 py-2 rounded-full border border-white/5 text-sm hover:bg-white/10 transition-colors">
            Save State
          </button>
        </div>
      </div>

      {/* Left Icon Bar */}
      <div className="absolute left-8 top-1/3 flex flex-col space-y-4 pointer-events-auto">
        <IconButton active={settings.elevation > 40} icon={<Sun className="w-5 h-5" />} tooltip="Clear Weather" onClick={() => handlePreset('clear')} />
        <IconButton active={settings.cloudOpacity > 0.8} icon={<CloudRain className="w-5 h-5" />} tooltip="Rainy/Overcast" onClick={() => handlePreset('overcast')} />
        <IconButton active={settings.elevation < 0} icon={<Moon className="w-5 h-5" />} tooltip="Night" onClick={() => handlePreset('night')} />
      </div>

      {/* Right Controls Panel */}
      <div className="absolute right-8 top-1/4 w-80 bg-[#1e1e1e]/80 backdrop-blur-xl rounded-3xl p-6 border border-white/5 shadow-2xl pointer-events-auto">
        
        {/* Panel Tabs */}
        <div className="flex justify-between items-center mb-6 border-b border-white/10 pb-4">
          <div className="flex space-x-2">
             <button onClick={() => setActiveTab('sky')} className={cn("w-8 h-8 rounded-full flex items-center justify-center transition-colors", activeTab === 'sky' ? "bg-white text-black" : "bg-white/10 text-white/70 hover:bg-white/20")}><Sun className="w-4 h-4" /></button>
             <button onClick={() => setActiveTab('clouds')} className={cn("w-8 h-8 rounded-full flex items-center justify-center transition-colors", activeTab === 'clouds' ? "bg-white text-black" : "bg-white/10 text-white/70 hover:bg-white/20")}><Cloud className="w-4 h-4" /></button>
             <button onClick={() => setActiveTab('fog')} className={cn("w-8 h-8 rounded-full flex items-center justify-center transition-colors", activeTab === 'fog' ? "bg-white text-black" : "bg-white/10 text-white/70 hover:bg-white/20")}><Wind className="w-4 h-4" /></button>
          </div>
          <Settings className="w-5 h-5 text-white/50 drop-shadow-md" />
        </div>

        <h3 className="text-white/90 text-sm font-medium mb-4 capitalize">{activeTab} Variables</h3>

        <div className="space-y-6">
          {activeTab === 'sky' && (
            <>
              <SliderControl label="Sun Elevation" value={settings.elevation} min={-10} max={90} onChange={(v) => handleSlider('elevation', v)} />
              <SliderControl label="Sun Azimuth" value={settings.azimuth} min={0} max={360} onChange={(v) => handleSlider('azimuth', v)} />
              <SliderControl label="Rayleigh Scattering" value={settings.rayleigh} min={0} max={10} step={0.1} onChange={(v) => handleSlider('rayleigh', v)} />
              <SliderControl label="Mie Turbidity (Haze)" value={settings.turbidity} min={0} max={20} step={0.1} onChange={(v) => handleSlider('turbidity', v)} />
            </>
          )}

          {activeTab === 'clouds' && (
            <>
              <SliderControl label="Cloud Density (Opacity)" value={settings.cloudOpacity} min={0} max={1} step={0.01} onChange={(v) => handleSlider('cloudOpacity', v)} />
              <SliderControl label="Noise Seed (Formation)" value={settings.cloudSeed} min={1} max={100} step={1} onChange={(v) => handleSlider('cloudSeed', v)} />
              <SliderControl label="Volume Fill" value={settings.cloudVolume} min={5} max={50} step={1} onChange={(v) => handleSlider('cloudVolume', v)} />
              <SliderControl label="Wind Speed" value={settings.cloudSpeed} min={0} max={2} step={0.1} onChange={(v) => handleSlider('cloudSpeed', v)} />
            </>
          )}

          {activeTab === 'fog' && (
            <>
              <SliderControl label="Volumetric Fog Density" value={settings.fogDensity} min={0} max={0.1} step={0.001} onChange={(v) => handleSlider('fogDensity', v)} />
              <div className="flex flex-col space-y-2">
                <span className="text-xs text-white/60">Fog Light Color</span>
                <input type="color" value={settings.fogColor} onChange={(e) => handleSlider('fogColor', e.target.value as any)} className="w-full h-8 bg-transparent cursor-pointer rounded-md overflow-hidden" />
              </div>
            </>
          )}
        </div>

        {/* Scene Outliner */}
        <div className="mt-8 border-t border-white/10 pt-6">
          <div className="flex items-center justify-between mb-3">
             <h3 className="text-white/90 text-sm font-medium">Outliner</h3>
             <span className="text-xs text-white/50 bg-black/20 px-2 py-0.5 rounded-full">{domes.length}</span>
          </div>
          <div className="space-y-2">
            {domes.map(dome => (
              <button
                key={dome.id}
                onClick={() => setActiveDomeId(dome.id)}
                className={cn("w-full text-left px-4 py-2 rounded-xl text-sm border transition-all flex items-center justify-between", activeDomeId === dome.id ? "bg-white/10 border-white/30 text-white shadow-inner" : "bg-black/20 border-transparent text-white/50 hover:bg-white/5")}
              >
                <span>{dome.name}</span>
                {activeDomeId === dome.id && <div className="w-2 h-2 rounded-full bg-green-400 shadow-[0_0_8px_rgba(74,222,128,0.8)]"></div>}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom Option Cards */}
      <div className="flex space-x-4 overflow-x-auto pb-4 pointer-events-auto hide-scrollbar w-full max-w-4xl max-w-">
        <OptionCard title="Clear Sky" desc="Rayleigh: 0.5, Turbidity: 2" onClick={() => handlePreset('clear')} />
        <OptionCard title="Sunset" desc="Rayleigh: 3, Turbidity: 10" onClick={() => handlePreset('sunset')} />
        <OptionCard title="Overcast" desc="Thick clouds, High turbidity" onClick={() => handlePreset('overcast')} />
        <OptionCard title="Night" desc="Negative elevation, stars" onClick={() => handlePreset('night')} />
      </div>
    </div>
  );
}

function IconButton({ icon, tooltip, active, onClick }: { icon: React.ReactNode; tooltip: string; active?: boolean; onClick?: () => void }) {
  return (
    <button 
      onClick={onClick}
      className={cn("group relative w-12 h-12 rounded-full backdrop-blur-md flex items-center justify-center transition-all border border-white/5", active ? "bg-white/20 text-white shadow-lg shadow-white/10" : "bg-black/40 text-white/70 hover:text-white hover:bg-white/10")}
      title={tooltip}
    >
      {icon}
    </button>
  );
}

function SliderControl({ label, value, min, max, step = 1, onChange }: { label: string; value: number; min: number; max: number; step?: number; onChange: (v: number) => void }) {
  return (
    <div className="flex flex-col space-y-2">
      <div className="flex justify-between text-xs text-white/60">
        <span>{label}</span>
        <span>{value.toFixed(step < 1 ? 2 : 0)}</span>
      </div>
      <input 
        type="range" 
        min={min} 
        max={max} 
        step={step} 
        value={value} 
        onChange={(e) => onChange(parseFloat(e.target.value))}
        className="w-full h-1 bg-white/20 rounded-lg appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-3 [&::-webkit-slider-thumb]:h-3 [&::-webkit-slider-thumb]:bg-white [&::-webkit-slider-thumb]:rounded-full"
      />
    </div>
  );
}

function OptionCard({ title, desc, onClick }: { title: string; desc: string; onClick: () => void }) {
  return (
    <button onClick={onClick} className="min-w-[200px] h-[100px] bg-[#1e1e1e]/80 backdrop-blur-md rounded-2xl p-4 flex flex-col justify-end text-left border border-white/5 hover:bg-white/10 transition-colors">
      <span className="text-white/60 text-xs mb-1">{desc}</span>
      <span className="text-white text-sm font-medium">{title}</span>
    </button>
  );
}
