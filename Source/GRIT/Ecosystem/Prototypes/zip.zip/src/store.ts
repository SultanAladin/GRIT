export interface AtmosphereSettings {
  elevation: number;
  azimuth: number;
  turbidity: number;
  rayleigh: number;
  mieCoefficient: number;
  mieDirectionalG: number;
  exposure: number;
  cloudOpacity: number;
  cloudSpeed: number;
  cloudColor: string;
  cloudVolume: number;
  cloudSeed: number;
  fogDensity: number;
  fogColor: string;
}

export const defaultSettings: AtmosphereSettings = {
  elevation: 2,
  azimuth: 180,
  turbidity: 10,
  rayleigh: 3,
  mieCoefficient: 0.005,
  mieDirectionalG: 0.7,
  exposure: 0.5,
  cloudOpacity: 0.8,
  cloudSpeed: 0.4,
  cloudColor: '#ffffff',
  cloudVolume: 20,
  cloudSeed: 1,
  fogDensity: 0.015,
  fogColor: '#ffb380',
};

export const presets = {
  clear: {
    ...defaultSettings,
    elevation: 45,
    turbidity: 2,
    rayleigh: 0.5,
    mieCoefficient: 0.005,
    cloudOpacity: 0.2,
    fogDensity: 0.002,
    fogColor: '#8ca8ff',
  },
  sunset: {
    ...defaultSettings,
    elevation: 2,
    turbidity: 10,
    rayleigh: 3,
    mieCoefficient: 0.005,
    cloudOpacity: 0.6,
    cloudColor: '#ffb380',
    fogDensity: 0.015,
    fogColor: '#ffb380',
  },
  overcast: {
    ...defaultSettings,
    elevation: 40,
    turbidity: 20,
    rayleigh: 1.5,
    mieCoefficient: 0.05,
    mieDirectionalG: 0.9,
    cloudOpacity: 1,
    cloudSpeed: 0.6,
    cloudColor: '#6c727c',
    cloudVolume: 40,
    fogDensity: 0.03,
    fogColor: '#6c727c',
  },
  night: {
    ...defaultSettings,
    elevation: -5,
    turbidity: 2,
    rayleigh: 1,
    mieCoefficient: 0.005,
    cloudOpacity: 0.1,
    fogDensity: 0.005,
    fogColor: '#0a0a1a',
  }
};
