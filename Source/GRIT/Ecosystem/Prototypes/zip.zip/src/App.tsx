import React, { useState, Suspense } from 'react';
import { Canvas } from '@react-three/fiber';
import { SkyScene } from './components/SkyScene';
import { UIOverlay } from './components/UIOverlay';
import { defaultSettings, presets } from './store';

export default function App() {
  const [domes, setDomes] = useState([
    { id: 1, name: 'Portal 1 (West)', position: [-150, 0, 0] as [number, number, number], settings: defaultSettings },
    { id: 2, name: 'Portal 2 (East)', position: [150, 0, 0] as [number, number, number], settings: presets.overcast }
  ]);
  const [activeDomeId, setActiveDomeId] = useState(1);

  return (
    <div className="w-full h-full relative bg-black">
      {/* 3D Canvas */}
      <Canvas shadows dpr={[1, 2]}>
        <Suspense fallback={null}>
          <SkyScene domes={domes} />
        </Suspense>
      </Canvas>

      {/* UI Overlay */}
      <UIOverlay domes={domes} setDomes={setDomes} activeDomeId={activeDomeId} setActiveDomeId={setActiveDomeId} />
    </div>
  );
}
